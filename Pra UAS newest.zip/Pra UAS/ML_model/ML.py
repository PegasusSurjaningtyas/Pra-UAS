import numpy as np
from sklearn import linear_model
from csv import writer
from django.conf import settings


class BaseLinearRegression:
    def __init__(self):
        self.dfx = np.array([1, 2, 3, 4, 5]).reshape((-1, 1))
        self.dfy = np.array([100,200,300,400,500])
        self.model = linear_model.LinearRegression()
        self.model.fit(self.df.iloc[:, 0:3], self.df.iloc[:, -1:])

    def predict(self, value):
        return self.model.predict([value])


ml_susutelur = BaseLinearRegression()

