from django.shortcuts import render
from django.shortcuts import get_object_or_404
from rest_framework.generics import RetrieveUpdateDestroyAPIView
from rest_framework.response import Response
import paho.mqtt.client as mqtt
import time
from sklearn.linear_model import LinearRegression

from .serializers import SensorSerializer
from .models import Sensor

import numpy as np
def estimate_coef(x, y):
    # number of observations/points
    n = np.size(x)

    # mean of x and y vector
    m_x = np.mean(x)
    m_y = np.mean(y)

    # calculating cross-deviation and deviation about x
    SS_xy = np.sum(y * x) - n * m_y * m_x
    SS_xx = np.sum(x * x) - n * m_x * m_x

    # calculating regression coefficients
    b_1 = SS_xy / SS_xx
    b_0 = m_y - b_1 * m_x

    return (b_0, b_1)

# x = np.array([1,2,3,4,5]).reshape(-1,1)
x = np.array([1, 2, 3, 4, 5]).reshape((-1, 1))
# bpm = np.array([95,93,97,85,60])
motor = []
temp = []
humid = []
pressure = []
light = []
motion = []
accelerometer = []
gyro = []
proxi = []
magnet = []
cylinder = []
pneumatic = []

infra = []
ultra = []
gas = []
smoke = []
CMO = []
co2 = []
ph = []
conduct = []
DOS = []
solenoid = []
piezo = []
alloy = []

TS = []
soil = []
water = []
flow = []
vibration = []
sound = []
color = []
magnet = []
radiation = []
electromagnet = []
linear = []
VoiceCoil = []

# coef_bpm = estimate_coef(x, bpm)
# coef_temp = estimate_coef(x, temp)
# coef_systole = estimate_coef(x, systole)
# coef_diastole = estimate_coef(x, diastole)
# coef_diastole = estimate_coef(x, diastole)
# coef_acidity = estimate_coef(x, acidity)
# coef_volume = estimate_coef(x, volume)
# coef_o2 = estimate_coef(x, o2)
# coef_tidal = estimate_coef(x, tidal)
# coef_kapasitas = estimate_coef(x, kapasitas)


# Create your views here.
def index(request):
    susu_motor = Sensor.objects.get(name="susu_motor")
    susu_temp = Sensor.objects.get(name="susu_temp")
    susu_humid = Sensor.objects.get(name="susu_humid")
    susu_pressure = Sensor.objects.get(name="susu_pressure")
    susu_light = Sensor.objects.get(name="susu_light")
    susu_motion = Sensor.objects.get(name="susu_motion")
    susu_accelerometer = Sensor.objects.get(name="susu_accelerometer")
    susu_gyro = Sensor.objects.get(name="susu_gyro")
    susu_proxi = Sensor.objects.get(name="susu_proxi")
    susu_magnet = Sensor.objects.get(name="susu_magnet")
    susu_cylinder = Sensor.objects.get(name="susu_cylinder")
    susu_pneumatic = Sensor.objects.get(name="susu_pneumatic")

    plant_infra = Sensor.objects.get(name="plant_infra")
    plant_ultra = Sensor.objects.get(name="plant_ultra")
    plant_gas = Sensor.objects.get(name="plant_gas")
    plant_smoke = Sensor.objects.get(name="plant_smoke")
    plant_CMO = Sensor.objects.get(name="plant_CMO")
    plant_co2 = Sensor.objects.get(name="plant_co2")
    plant_ph = Sensor.objects.get(name="plant_ph")
    plant_conduct = Sensor.objects.get(name="plant_conduct")
    plant_DOS = Sensor.objects.get(name="plant_DOS")
    plant_solenoid = Sensor.objects.get(name="plant_solenoid")
    plant_piezo = Sensor.objects.get(name="plant_piezo")
    plant_alloy = Sensor.objects.get(name="plant_alloy")

    resto_TS = Sensor.objects.get(name="resto_TS")
    resto_soil = Sensor.objects.get(name="resto_soil")
    resto_water = Sensor.objects.get(name="resto_water")
    resto_flow = Sensor.objects.get(name="resto_flow")
    resto_vibration = Sensor.objects.get(name="resto_vibration")
    resto_sound = Sensor.objects.get(name="resto_sound")
    resto_color = Sensor.objects.get(name="resto_color")
    resto_magnet = Sensor.objects.get(name="resto_magnet")
    resto_radiation = Sensor.objects.get(name="resto_radiation")
    resto_electromagnet = Sensor.objects.get(name="resto_electromagnet")
    resto_linear = Sensor.objects.get(name="resto_linear")
    resto_VoiceCoil = Sensor.objects.get(name="resto_VoiceCoil")

    context = {
        'susu_motor' : str(susu_motor.value),
        'susu_temp' : str(susu_temp.value),
        'susu_humid': str(susu_humid.value),
        'susu_pressure': str(susu_pressure.value),
        'susu_light': str(susu_light.value),
        'susu_motion': str(susu_motion.value),
        'susu_accelerometer': str(susu_accelerometer.value),
        'susu_gyro': str(susu_gyro.value),
        'susu_magnet': str(susu_magnet.value),
        'susu_proxi': str(susu_proxi.value),
        'susu_cylinder': str(susu_cylinder.value),
        'susu_pneumatic': str(susu_pneumatic.value),
        'plant_infra' : str(plant_infra.value),
        'plant_ultra' : str(plant_ultra.value),
        'plant_gas' : str(plant_gas.value),
        'plant_smoke' : str(plant_smoke.value),
        'plant_CMO' : str(plant_CMO.value),
        'plant_co2' : str(plant_co2.value),
        'plant_ph' : str(plant_ph.value),
        'plant_conduct' : str(plant_conduct.value),
        'plant_DOS' : str(plant_DOS.value),
        'plant_solenoid': str(plant_solenoid.value),
        'plant_piezo': str(plant_piezo.value),
        'plant_alloy': str(plant_alloy.value),
        'resto_TS': str(resto_TS.value),
        'resto_soil': str(resto_soil.value),
        'resto_water': str(resto_water.value),
        'resto_flow': str(resto_flow.value),
        'resto_vibration': str(resto_vibration.value),
        'resto_sound': str(resto_sound.value),
        'resto_color': str(resto_color.value),
        'resto_magnet': str(resto_magnet.value),
        'resto_radiation': str(resto_radiation.value),
        'resto_electromagnet': str(resto_electromagnet.value),
        'resto_linear': str(resto_linear.value),
        'resto_VoiceCoil': str(resto_VoiceCoil.value)
    }

    return render(request, 'index.html', context)

ml_test = 0


def on_message_motor(client, userdata, msg):
    susu_motor = Sensor.objects.get(name="susu_motor")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(susu_motor, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new MOTOR data ', msg.payload.decode('utf-8'))
    if len(motor) < 5:
        motor.append(int(msg.payload.decode('utf-8')))
    else:
        motor_array = np.array(motor)
        reg = LinearRegression().fit(x, motor_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        # print("expected motor result is: ", reg.predict(predict))
        ml_test = reg.predict(predict)
        print("expected motor result is: ", ml_test)
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))

def on_message_pneumatic(client, userdata, msg):
    susu_pneumatic = Sensor.objects.get(name="susu_pneumatic")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(susu_pneumatic, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new pneumatic data ', msg.payload.decode('utf-8'))
    #print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(pneumatic) < 5:
        pneumatic.append(int(msg.payload.decode('utf-8')))
        print(pneumatic)
    else:
        pneumatic_array = np.array(pneumatic)
        reg = LinearRegression().fit(x, pneumatic_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected pneumatic result is: ", reg.predict(predict))

def on_message_cylinder(client, userdata, msg):
    susu_cylinder = Sensor.objects.get(name="susu_cylinder")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(susu_cylinder, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new cylinder data ', msg.payload.decode('utf-8'))
    #print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(cylinder) < 5:
        cylinder.append(int(msg.payload.decode('utf-8')))
    else:
        cylinder_array = np.array(cylinder)
        reg = LinearRegression().fit(x, cylinder_array)
        predict_cylinder = []
        predict_cylinder.append([int(msg.payload.decode('utf-8'))])
        print("expected cylinder result is: ", reg.predict(predict_cylinder))

def on_message_temp(client, userdata, msg):
    susu_temp = Sensor.objects.get(name="susu_temp")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(susu_temp, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new TEMP data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(temp) < 5:
        temp.append(int(msg.payload.decode('utf-8')))
    else:
        temp_array = np.array(temp)
        reg = LinearRegression().fit(x, temp_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected temp result is: ", reg.predict(predict))

def on_message_humid(client, userdata, msg):
    susu_humid = Sensor.objects.get(name="susu_humid")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(susu_humid, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new HUMID data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(humid) < 5:
        humid.append(int(msg.payload.decode('utf-8')))
    else:
        humid_array = np.array(humid)
        reg = LinearRegression().fit(x, humid_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected humid result is: ", reg.predict(predict))

def on_message_pressure(client, userdata, msg):
    susu_pressure = Sensor.objects.get(name="susu_pressure")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(susu_pressure, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new PRESSURE data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(pressure) < 5:
        pressure.append(int(msg.payload.decode('utf-8')))
    else:
        pressure_array = np.array(pressure)
        reg = LinearRegression().fit(x, pressure_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected pressure result is: ", reg.predict(predict))


def on_message_light(client, userdata, msg):
    susu_light = Sensor.objects.get(name="susu_light")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(susu_light, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new LIGHT data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(light) < 5:
        light.append(int(msg.payload.decode('utf-8')))
    else:
        light_array = np.array(light)
        reg = LinearRegression().fit(x, light_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected light result is: ", reg.predict(predict))

def on_message_motion(client, userdata, msg):
    susu_motion = Sensor.objects.get(name="susu_motion")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(susu_motion, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new MOTION data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(motion) < 5:
        motion.append(int(msg.payload.decode('utf-8')))
    else:
        motion_array = np.array(motion)
        reg = LinearRegression().fit(x, motion_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected motion result is: ", reg.predict(predict))


def on_message_accelerometer(client, userdata, msg):
    susu_accelerometer = Sensor.objects.get(name="susu_accelerometer")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(susu_accelerometer, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new ACCELEROMETER data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(accelerometer) < 5:
        accelerometer.append(int(msg.payload.decode('utf-8')))
    else:
        accelerometer_array = np.array(accelerometer)
        reg = LinearRegression().fit(x, accelerometer_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))

def on_message_gyro(client, userdata, msg):
    susu_gyro = Sensor.objects.get(name="susu_gyro")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(susu_gyro, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new GYRO data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(gyro) < 5:
        gyro.append(int(msg.payload.decode('utf-8')))
    else:
        gyro_array = np.array(gyro)
        reg = LinearRegression().fit(x, gyro_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))

def on_message_magnet(client, userdata, msg):
    susu_magnet = Sensor.objects.get(name="susu_magnet")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(susu_magnet, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new MAGNET data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(magnet) < 5:
        magnet.append(int(msg.payload.decode('utf-8')))
    else:
        magnet_array = np.array(magnet)
        reg = LinearRegression().fit(x, magnet_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))

def on_message_proxi(client, userdata, msg):
    susu_proxi = Sensor.objects.get(name="susu_proxi")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(susu_proxi, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new PROXI data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(proxi) < 5:
        proxi.append(int(msg.payload.decode('utf-8')))
    else:
        proxi_array = np.array(proxi)
        reg = LinearRegression().fit(x, proxi_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))

def on_message_infra(client, userdata, msg):
    plant_infra = Sensor.objects.get(name="plant_infra")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(plant_infra, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new INFRA data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(infra) < 5:
        infra.append(int(msg.payload.decode('utf-8')))
    else:
        infra_array = np.array(infra)
        reg = LinearRegression().fit(x, infra_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))


def on_message_ultra(client, userdata, msg):
    plant_ultra = Sensor.objects.get(name="plant_ultra")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(plant_ultra, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new ULTRA data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(ultra) < 5:
        ultra.append(int(msg.payload.decode('utf-8')))
    else:
        ultra_array = np.array(ultra)
        reg = LinearRegression().fit(x, ultra_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))



def on_message_gas(client, userdata, msg):
    plant_gas = Sensor.objects.get(name="plant_gas")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(plant_gas, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new GAS data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(gas) < 5:
        gas.append(int(msg.payload.decode('utf-8')))
    else:
        gas_array = np.array(gas)
        reg = LinearRegression().fit(x, gas_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))



def on_message_smoke(client, userdata, msg):
    plant_smoke = Sensor.objects.get(name="plant_smoke")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(plant_smoke, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new SMOKE data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(smoke) < 5:
        smoke.append(int(msg.payload.decode('utf-8')))
    else:
        smoke_array = np.array(smoke)
        reg = LinearRegression().fit(x, smoke_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))


def on_message_CMO(client, userdata, msg):
    plant_CMO = Sensor.objects.get(name="plant_CMO")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(plant_CMO, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new CMO data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(CMO) < 5:
        CMO.append(int(msg.payload.decode('utf-8')))
    else:
        CMO_array = np.array(CMO)
        reg = LinearRegression().fit(x, CMO_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))


def on_message_co2(client, userdata, msg):
    plant_co2 = Sensor.objects.get(name="plant_co2")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(plant_co2, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new CO2 data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(co2) < 5:
        co2.append(int(msg.payload.decode('utf-8')))
    else:
        co2_array = np.array(co2)
        reg = LinearRegression().fit(x, co2_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))


def on_message_ph(client, userdata, msg):
    plant_ph = Sensor.objects.get(name="plant_ph")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(plant_ph, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new PH data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(ph) < 5:
        ph.append(int(msg.payload.decode('utf-8')))
    else:
        ph_array = np.array(ph)
        reg = LinearRegression().fit(x, ph_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))


def on_message_conduct(client, userdata, msg):
    plant_conduct = Sensor.objects.get(name="plant_conduct")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(plant_conduct, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new CONDUCTIVITY data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(conduct) < 5:
        conduct.append(int(msg.payload.decode('utf-8')))
    else:
        conduct_array = np.array(conduct)
        reg = LinearRegression().fit(x, conduct_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))


def on_message_DOS(client, userdata, msg):
    plant_DOS = Sensor.objects.get(name="plant_DOS")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(plant_DOS, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new DOS data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(DOS) < 5:
        DOS.append(int(msg.payload.decode('utf-8')))
    else:
        DOS_array = np.array(DOS)
        reg = LinearRegression().fit(x, DOS_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))


def on_message_solenoid(client, userdata, msg):
    plant_solenoid = Sensor.objects.get(name="plant_solenoid")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(plant_solenoid, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new solenoid data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(solenoid) < 5:
        solenoid.append(int(msg.payload.decode('utf-8')))
    else:
        solenoid_array = np.array(solenoid)
        reg = LinearRegression().fit(x, solenoid_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))

def on_message_piezo(client, userdata, msg):
    plant_piezo = Sensor.objects.get(name="plant_piezo")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(plant_piezo, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new piezo data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(piezo) < 5:
        piezo.append(int(msg.payload.decode('utf-8')))
    else:
        piezo_array = np.array(piezo)
        reg = LinearRegression().fit(x, piezo)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))

def on_message_alloy(client, userdata, msg):
    plant_alloy = Sensor.objects.get(name="plant_alloy")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(plant_alloy, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new alloy data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(alloy) < 5:
        alloy.append(int(msg.payload.decode('utf-8')))
    else:
        alloy_array = np.array(alloy)
        reg = LinearRegression().fit(x, alloy_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))

def on_message_TS(client, userdata, msg):
    resto_TS = Sensor.objects.get(name="resto_TS")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(resto_TS, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new TS data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(TS) < 5:
        TS.append(int(msg.payload.decode('utf-8')))
    else:
        TS_array = np.array(TS)
        reg = LinearRegression().fit(x, TS_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))

def on_message_soil(client, userdata, msg):
    resto_soil = Sensor.objects.get(name="resto_soil")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(resto_soil, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new SOIL data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(soil) < 5:
        soil.append(int(msg.payload.decode('utf-8')))
    else:
        soil_array = np.array(soil)
        reg = LinearRegression().fit(x, soil_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))

def on_message_water(client, userdata, msg):
    resto_water = Sensor.objects.get(name="resto_water")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(resto_water, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new WATER data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(water) < 5:
        water.append(int(msg.payload.decode('utf-8')))
    else:
        water_array = np.array(water)
        reg = LinearRegression().fit(x, water_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))

def on_message_flow(client, userdata, msg):
    resto_flow = Sensor.objects.get(name="resto_flow")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(resto_flow, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new FLOW data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(flow) < 5:
        flow.append(int(msg.payload.decode('utf-8')))
    else:
        flow_array = np.array(flow)
        reg = LinearRegression().fit(x, flow_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))


def on_message_vibration(client, userdata, msg):
    resto_vibration = Sensor.objects.get(name="resto_vibration")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(resto_vibration, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new VIBRATION data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(vibration) < 5:
        vibration.append(int(msg.payload.decode('utf-8')))
    else:
        vibration_array = np.array(vibration)
        reg = LinearRegression().fit(x, vibration_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))

def on_message_sound(client, userdata, msg):
    resto_sound = Sensor.objects.get(name="resto_sound")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(resto_sound, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new SOUND data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(sound) < 5:
        sound.append(int(msg.payload.decode('utf-8')))
    else:
        sound_array = np.array(sound)
        reg = LinearRegression().fit(x, sound_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))

def on_message_color(client, userdata, msg):
    resto_color = Sensor.objects.get(name="resto_color")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(resto_color, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new COLOR data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(color) < 5:
        color.append(int(msg.payload.decode('utf-8')))
    else:
        color_array = np.array(color)
        reg = LinearRegression().fit(x, color_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))

def on_message_magnet(client, userdata, msg):
    resto_magnet = Sensor.objects.get(name="resto_magnet")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(resto_magnet, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new MAGNET data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(magnet) < 5:
        magnet.append(int(msg.payload.decode('utf-8')))
    else:
        magnet_array = np.array(magnet)
        reg = LinearRegression().fit(x, magnet_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))

def on_message_radiation(client, userdata, msg):
    resto_radiation = Sensor.objects.get(name="resto_radiation")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(resto_radiation, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new RADIATION data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(radiation) < 5:
        radiation.append(int(msg.payload.decode('utf-8')))
    else:
        radiation_array = np.array(radiation)
        reg = LinearRegression().fit(x, radiation_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))

def on_message_electromagnet(client, userdata, msg):
    resto_electromagnet = Sensor.objects.get(name="resto_electromagnet")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(resto_electromagnet, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new electromagnet data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(electromagnet) < 5:
        electromagnet.append(int(msg.payload.decode('utf-8')))
    else:
        electromagnet_array = np.array(electromagnet)
        reg = LinearRegression().fit(x, electromagnet_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))

def on_message_linear(client, userdata, msg):
    resto_linear = Sensor.objects.get(name="resto_linear")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(resto_linear, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new linear data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(linear) < 5:
        linear.append(int(msg.payload.decode('utf-8')))
    else:
        linear_array = np.array(linear)
        reg = LinearRegression().fit(x, linear_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))

def on_message_VoiceCoil(client, userdata, msg):
    resto_VoiceCoil = Sensor.objects.get(name="resto_VoiceCoil")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(resto_VoiceCoil, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new VoiceCoil data ', msg.payload.decode('utf-8'))
    # print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    if len(VoiceCoil) < 5:
        VoiceCoil.append(int(msg.payload.decode('utf-8')))
    else:
        VoiceCoil_array = np.array(VoiceCoil)
        reg = LinearRegression().fit(x, VoiceCoil_array)
        predict = []
        predict.append([int(msg.payload.decode('utf-8'))])
        print("expected accelerometer result is: ", reg.predict(predict))

client = mqtt.Client("sensor")

# client.message_callback_add('paru/oxygen', on_message_oxy)
# client.message_callback_add('paru/tidal', on_message_tid)
# client.message_callback_add('paru/capacity', on_message_cap)
#
# client.message_callback_add('lambung/acid', on_message_acid)
# client.message_callback_add('lambung/volume', on_message_vol)
# client.message_callback_add('lambung/temp', on_message_temp)
#
# client.message_callback_add('jantung/rate', on_message_bpm)
# client.message_callback_add('jantung/systole', on_message_sys)
# client.message_callback_add('jantung/diastole', on_message_dia)
client.message_callback_add('susu/motor', on_message_motor)
client.message_callback_add('susu/temp', on_message_temp)
client.message_callback_add('susu/humid', on_message_humid)
client.message_callback_add('susu/pressure', on_message_pressure)
client.message_callback_add('susu/light', on_message_light)
client.message_callback_add('susu/motion', on_message_motion)
client.message_callback_add('susu/accelerometer', on_message_accelerometer)
client.message_callback_add('susu/gyro', on_message_gyro)
client.message_callback_add('susu/magnet', on_message_magnet)
client.message_callback_add('susu/proxi', on_message_proxi)
client.message_callback_add('susu/cylinder', on_message_cylinder)
client.message_callback_add('susu/pneumatic', on_message_pneumatic)

client.message_callback_add('plant/infra', on_message_infra)
client.message_callback_add('plant/ultra', on_message_ultra)
client.message_callback_add('plant/gas', on_message_gas)
client.message_callback_add('plant/smoke', on_message_smoke)
client.message_callback_add('plant/CMO', on_message_CMO)
client.message_callback_add('plant/co2', on_message_co2)
client.message_callback_add('plant/ph', on_message_ph)
client.message_callback_add('plant/conduct', on_message_conduct)
client.message_callback_add('plant/DOS', on_message_DOS)
client.message_callback_add('plant/solenoid', on_message_solenoid)
client.message_callback_add('plant/piezo', on_message_piezo)
client.message_callback_add('plant/alloy', on_message_alloy)

client.message_callback_add('resto/TS', on_message_TS)
client.message_callback_add('resto/soil', on_message_soil)
client.message_callback_add('resto/water', on_message_water)
client.message_callback_add('resto/flow', on_message_flow)
client.message_callback_add('resto/vibration', on_message_vibration)
client.message_callback_add('resto/sound', on_message_sound)
client.message_callback_add('resto/color', on_message_color)
client.message_callback_add('resto/magnet', on_message_magnet)
client.message_callback_add('resto/radiation', on_message_radiation)
client.message_callback_add('resto/electromagnet', on_message_electromagnet)
client.message_callback_add('resto/linear', on_message_linear)
client.message_callback_add('resto/VoiceCoil', on_message_VoiceCoil)



client.connect('localhost', 1883)
client.loop_start()
client.subscribe('#')