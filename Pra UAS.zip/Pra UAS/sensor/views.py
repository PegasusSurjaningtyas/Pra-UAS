from django.shortcuts import render
from django.shortcuts import get_object_or_404
from rest_framework.generics import RetrieveUpdateDestroyAPIView
from rest_framework.response import Response
import paho.mqtt.client as mqtt
import time


from .serializers import SensorSerializer
from .models import Sensor

import numpy as np
def estimate_coef(x, y):
    # number of observations/points
    n = np.size(x)

    # mean of x and y vector
    m_x = np.mean(x)
    m_y = np.mean(y)

    # calculating cross-deviation and deviation about x
    SS_xy = np.sum(y * x) - n * m_y * m_x
    SS_xx = np.sum(x * x) - n * m_x * m_x

    # calculating regression coefficients
    b_1 = SS_xy / SS_xx
    b_0 = m_y - b_1 * m_x

    return (b_0, b_1)

x = np.array([1,2,3,4,5])
bpm = np.array([95,93,97,85,60])
temp = np.array([30,50,37,39,37])
systole = np.array([113,118,87,87,76])
diastole = np.array([64,56,88,65,64])
acidity = np.array([1,1,3,5,6])
volume = np.array([20,100,26,55,60])
o2 = np.array([77,84,91,95,88])
tidal = np.array([400,405,410,422,600])
kapasitas = np.array([3006,4242,3180,3220,5000])
coef_bpm = estimate_coef(x, bpm)
coef_temp = estimate_coef(x, temp)
coef_systole = estimate_coef(x, systole)
coef_diastole = estimate_coef(x, diastole)
coef_acidity = estimate_coef(x, acidity)
coef_volume = estimate_coef(x, volume)
coef_o2 = estimate_coef(x, o2)
coef_tidal = estimate_coef(x, tidal)
coef_kapasitas = estimate_coef(x, kapasitas)


# Create your views here.
def index(request):
    paru_oxy = Sensor.objects.get(name="paru_oxy")
    paru_tid = Sensor.objects.get(name="paru_tid")
    paru_cap = Sensor.objects.get(name="paru_cap")

    lambung_acid = Sensor.objects.get(name="lambung_acid")
    lambung_vol = Sensor.objects.get(name="lambung_vol")
    lambung_temp = Sensor.objects.get(name="lambung_temp")

    jantung_bpm = Sensor.objects.get(name="jantung_bpm")
    jantung_sys = Sensor.objects.get(name="jantung_sys")
    jantung_dia = Sensor.objects.get(name="jantung_dia")
    # susu_motor = Sensor.objects.get(name="susu_motor")

    context = {
        'paru_oxy': str(paru_oxy.value),
        'paru_tid': str(paru_tid.value),
        'paru_cap': str(paru_cap.value),

        'lambung_acid': str(lambung_acid.value),
        'lambung_vol': str(lambung_vol.value),
        'lambung_temp': str(lambung_temp.value),

        'jantung_bpm': str(jantung_bpm.value),
        'jantung_sys': str(jantung_sys.value),
        'jantung_dia': str(jantung_dia.value)
        # 'susu_motor' : str(susu_motor.value)
    }

    return render(request, 'index.html', context)


# def on_message_motor(client, userdata, msg):
#     susu_motor = Sensor.objects.get(name="susu_motor")
#     data = {
#         'value': msg.payload.decode('utf-8')
#     }
#     serializer = SensorSerializer(susu_motor, data=data, partial=True)
#     if serializer.is_valid():
#         serializer.save()
#     print('received a new MOTOR data ', msg.payload.decode('utf-8'))
#     print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))


def on_message_oxy(client, userdata, msg):
    paru_oxy = Sensor.objects.get(name="paru_oxy")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(paru_oxy, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new OXYGEN data ', msg.payload.decode('utf-8'))
    print("predicted data is: ", coef_o2[0] + coef_o2[1] * int(msg.payload.decode('utf-8')))
    
def on_message_tid(client, userdata, msg):
    paru_tid = Sensor.objects.get(name="paru_tid")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(paru_tid, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new TIDAL data ', msg.payload.decode('utf-8'))
    print("predicted data is: ", coef_tidal[0] + coef_tidal[1] * int(msg.payload.decode('utf-8')))
     
def on_message_cap(client, userdata, msg):
    paru_cap = Sensor.objects.get(name="paru_cap")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(paru_cap, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new CAPACITY data ', msg.payload.decode('utf-8'))
    print("predicted data is: ", coef_acidity[0] + coef_acidity[1] * int(msg.payload.decode('utf-8')))



def on_message_acid(client, userdata, msg):
    lambung_acid = Sensor.objects.get(name="lambung_acid")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(lambung_acid, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new ACIDITY data ', msg.payload.decode('utf-8'))
    print("predicted data is: ", coef_acidity[0] + coef_acidity[1] * float(msg.payload.decode('utf-8')))

def on_message_vol(client, userdata, msg):
    lambung_vol = Sensor.objects.get(name="lambung_vol")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(lambung_vol, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new VOLUME data ', msg.payload.decode('utf-8'))
    print("predicted data is: ", coef_volume[0] + coef_volume[1] * int(msg.payload.decode('utf-8')))

def on_message_temp(client, userdata, msg):
    lambung_temp = Sensor.objects.get(name="lambung_temp")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(lambung_temp, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new TEMPERATURE data ', msg.payload.decode('utf-8'))
    print("predicted data is: ", coef_temp[0] + coef_temp[1]*int(msg.payload.decode('utf-8')))



def on_message_bpm(client, userdata, msg):
    jantung_bpm = Sensor.objects.get(name="jantung_bpm")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(jantung_bpm, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new BPM data ', msg.payload.decode('utf-8'))
    print("predicted data is: ", coef_bpm[0] + coef_bpm[1] * int(msg.payload.decode('utf-8')))

def on_message_sys(client, userdata, msg):
    jantung_sys = Sensor.objects.get(name="jantung_sys")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(jantung_sys, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new SYSTOLE data ', msg.payload.decode('utf-8'))
    print("predicted data is: ", coef_systole[0] + coef_systole[1] * int(msg.payload.decode('utf-8')))

def on_message_dia(client, userdata, msg):
    jantung_dia = Sensor.objects.get(name="jantung_dia")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(jantung_dia, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()
    print('received a new DIASTOLE data ', msg.payload.decode('utf-8'))
    print("predicted data is: ", coef_diastole[0] + coef_diastole[1] * int(msg.payload.decode('utf-8')))



client = mqtt.Client("sensor")

client.message_callback_add('paru/oxygen', on_message_oxy)
client.message_callback_add('paru/tidal', on_message_tid)
client.message_callback_add('paru/capacity', on_message_cap)

client.message_callback_add('lambung/acid', on_message_acid)
client.message_callback_add('lambung/volume', on_message_vol)
client.message_callback_add('lambung/temp', on_message_temp)

client.message_callback_add('jantung/rate', on_message_bpm)
client.message_callback_add('jantung/systole', on_message_sys)
client.message_callback_add('jantung/diastole', on_message_dia)
# client.message_callback_add('susu/motor', on_message_motor)

client.connect('localhost', 1883)
client.loop_start()
client.subscribe('#')